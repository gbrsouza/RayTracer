#ifndef _SAMPLE_H_
#define _SAMPLE_H_

class Sampler {};

#endif