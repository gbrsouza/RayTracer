#ifndef _PLANE_H_
#define _PLANE_H_

#include "shape.h"

class Plane : public Shape {};

#endif