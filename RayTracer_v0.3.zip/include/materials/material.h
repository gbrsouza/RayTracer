#ifndef _MATERIAL_H_
#define _MATERIAL_H_

class Material{

};

#endif