#ifndef _TRIANGLE_H_
#define  _TRIANGLE_H_

#include "shape.h"

class Triangle : public Shape {};

#endif