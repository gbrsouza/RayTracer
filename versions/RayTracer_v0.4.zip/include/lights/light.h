#ifndef _LIGHT_H_
#define _LIGHT_H_

class Light {};

#endif